export const menuItems = [{
  key: 'insights',
  label: 'Insights',
  isTitle: true
}, {
  key: 'dashboards',
  label: 'Dashboards',
  icon: '/icons/sprite.svg#trello',
  badge: {
    variant: 'bg-danger-700',
    text: 'New'
  },
  children: [{
    key: 'control-center',
    label: 'Control Center',
    url: '/dashboards/control-center'
  }, {
    key: 'subscription',
    label: 'Subscription & Billing',
    url: '/dashboards/subscription'
  }, {
    key: 'marketing',
    label: 'Marketing & Sales',
    url: '/dashboards/marketing'
  }, {
    key: 'project-management',
    label: 'Project Management',
    url: '/dashboards/project-management'
  }]
}, {
  key: 'config',
  label: 'Config',
  isTitle: true
}, {
  icon: '/icons/sprite.svg#cpu',
  key: 'appintel',
  label: 'Application Intel',
  url: '/appintel'
}, {
  icon: '/icons/sprite.svg#home',
  key: 'blank-page',
  label: 'Blank Page',
  url: '/blank-page'
}, {
  key: 'layouts',
  label: 'Layouts',
  isTitle: true
}, {
  icon: '/icons/sprite.svg#slash',
  key: 'access-control',
  label: 'Access Control',
  children: [{
    key: 'authentication-pages',
    label: 'Authentication Pages',
    children: [{
      key: 'access-control-auth-login',
      label: 'Login',
      url: '/auth/login'
    }, {
      key: 'access-control-auth-register',
      label: 'Register',
      url: '/auth/register'
    }, {
      key: 'access-control-auth-forget-password',
      label: 'Forget Password',
      url: '/auth/forgot-password'
    }, {
      key: 'access-control-auth-two-factor',
      label: '2FA',
      url: '/auth/two-factor'
    }, {
      key: 'access-control-auth-lockscreen',
      label: 'Lock Screen',
      url: '/auth/lockscreen'
    }]
  }, {
    key: 'email-template',
    label: 'Email Templates',
    url: '/email-template'
  }, {
    key: 'error-pages',
    label: 'Error Pages',
    children: [{
      key: 'error-404-1',
      label: '404 Not Found',
      url: '/404'
    }, {
      key: 'error-404-2',
      label: '404 Not Found 2',
      url: '/error/404-2'
    }, {
      key: 'error-500',
      label: '500 Internal Server',
      url: '/error/500'
    }]
  }, {
    key: 'user-profile',
    label: 'User Profile',
    url: '/access-control/user-profile'
  }]
}, {
  icon: '/icons/sprite.svg#message-square',
  key: 'communication',
  label: 'Communication',
  children: [{
    key: 'messenger',
    label: 'Messenger & Chat',
    url: '/messenger'
  }, {
    key: 'email',
    label: 'Email',
    children: [{
      key: 'email-systemmail',
      label: 'System Mail',
      url: '/email/systemmail'
    }, {
      key: 'email-mailread',
      label: 'Mail Read',
      url: '/email/mailread'
    }]
  }, {
    key: 'usercontact',
    label: 'User Contact',
    url: '/usercontact'
  }]
}, {
  icon: '/icons/sprite.svg#archive',
  key: 'miscellaneous',
  label: 'Miscellaneous',
  children: [{
    key: 'forum-general',
    label: 'Forum General',
    url: '/forum/general'
  }, {
    key: 'forum-threads',
    label: 'Forum Threads',
    url: '/forum/threads'
  }, {
    key: 'forum-discussions',
    label: 'Forum Discussions',
    url: '/forum/discussions'
  }, {
    key: 'forum-search',
    label: 'Search',
    url: '/forum/search'
  }]
}, {
  key: 'design',
  label: 'Design',
  isTitle: true
}, {
  key: 'ui-components',
  icon: '/icons/sprite.svg#layers',
  label: 'UI Components',
  children: [{
    key: 'alerts',
    label: 'Alerts',
    url: '/ui/alerts'
  }, {
    key: 'accordions',
    label: 'Accordions',
    url: '/ui/accordions'
  }, {
    key: 'badges',
    label: 'Badges',
    url: '/ui/badges'
  }, {
    key: 'buttons',
    label: 'Buttons',
    url: '/ui/buttons'
  }, {
    key: 'button-groups',
    label: 'Button Groups',
    url: '/ui/button-groups'
  }, {
    key: 'cards',
    label: 'Cards',
    url: '/ui/cards'
  }, {
    key: 'breadcrumbs',
    label: 'Breadcrumbs',
    url: '/ui/breadcrumbs'
  }, {
    key: 'dropdowns',
    label: 'Dropdowns',
    url: '/ui/dropdowns'
  }, {
    key: 'navbars',
    label: 'Navbars',
    url: '/ui/navbars'
  }, {
    key: 'pagination',
    label: 'Pagination',
    url: '/ui/pagination'
  }, {
    key: 'collapse',
    label: 'Collapse',
    url: '/ui/collapse'
  }, {
    key: 'modal',
    label: 'Modal',
    url: '/ui/modal'
  }, {
    key: 'tabs-pills',
    label: 'Tabs & Pills',
    url: '/ui/tabs-pills'
  }, {
    key: 'tooltips',
    label: 'Tooltips',
    url: '/ui/tooltips'
  }, {
    key: 'popovers',
    label: 'Popovers',
    url: '/ui/popovers'
  }, {
    key: 'toasts',
    label: 'Toasts',
    url: '/ui/toasts'
  }, {
    key: 'progress-bars',
    label: 'Progress Bars',
    url: '/ui/progress'
  }, {
    key: 'spinners',
    label: 'Spinners',
    url: '/ui/spinners'
  }, {
    key: 'carousels',
    label: 'Carousels',
    url: '/ui/carousels'
  }, {
    key: 'panels',
    label: 'Panels',
    url: '/ui/panels'
  }, {
    key: 'list-filter',
    label: 'List Filter',
    url: '/ui/list-filter'
  }, {
    key: 'side-panels',
    label: 'Side Panels',
    url: '/ui/side-panels'
  }]
}, {
  key: 'utilities',
  icon: '/icons/sprite.svg#package',
  label: 'System Utilities',
  children: [{
    key: 'borders',
    label: 'Borders',
    url: '/utilities/borders'
  }, {
    key: 'display-property',
    label: 'Display Property',
    url: '/utilities/display-property'
  }, {
    key: 'responsivegrid',
    label: 'Responsive Grid',
    url: '/utilities/responsivegrid'
  }, {
    key: 'position',
    label: 'Position',
    url: '/utilities/position'
  }, {
    key: 'colorpalette',
    label: 'Color Palette',
    url: '/utilities/colorpalette'
  }, {
    key: 'typography',
    label: 'Typography',
    url: '/utilities/typography'
  }, {
    key: 'sizing',
    label: 'Sizing',
    url: '/utilities/sizing'
  }, {
    key: 'spacing',
    label: 'Spacing',
    url: '/utilities/spacing'
  }, {
    key: 'flexbox',
    label: 'Flexbox',
    url: '/utilities/flexbox'
  }, {
    key: 'helpers',
    label: 'Helpers',
    url: '/utilities/helpers'
  }, {
    key: 'visibility-generator',
    label: 'Visibility Generator',
    url: '/utilities/visibility-generator'
  }]
}, {
  key: 'error-iconography',
  icon: '/icons/sprite.svg#heart',
  label: 'Iconography',
  children: [{
    key: 'system-icon',
    label: 'System Icons',
    url: '/icons/system'
  }, {
    key: 'font-awesome',
    label: 'FontAwesome',
    url: '/icons/font-awesome'
  }, {
    key: 'smart-icon',
    label: 'Smart Admin Icons',
    url: '/icons/smart-admin'
  }]
}, {
  key: 'tables',
  icon: '/icons/sprite.svg#table',
  label: 'Tables',
  children: [{
    key: 'basic-tables',
    label: 'Basic Tables',
    url: '/tables/basic'
  }, {
    key: 'table-style-generator',
    label: 'Table Style Generator',
    url: '/tables/style-generator'
  }]
}, {
  key: 'forms',
  icon: '/icons/sprite.svg#edit',
  label: 'Forms',
  children: [{
    key: 'forms-inputs',
    label: 'Inputs',
    url: '/forms/inputs'
  }, {
    key: 'forms-checkbox-radio',
    label: 'Checkbox & Radio',
    url: '/forms/checkbox-radio'
  }, {
    key: 'forms-groups',
    label: 'Groups',
    url: '/forms/groups'
  }, {
    key: 'forms-validation',
    label: 'Validation',
    url: '/forms/validation'
  }]
}, {
  key: 'data-visualization',
  label: 'Data Visualization',
  isTitle: true
}, {
  key: 'smart-tables',
  icon: '/icons/sprite.svg#database',
  label: 'Smart Tables',
  badge: {
    variant: 'bg-primary-500',
    text: '1.2.7'
  },
  children: [{
    key: 'smarttables-minimal',
    label: 'Minimal Settings',
    url: '/smarttables/minimal'
  }, {
    key: 'smarttables-responsive',
    label: 'Responsive Settings',
    url: '/smarttables/responsive'
  }, {
    key: 'smarttables-importexport-data',
    label: 'Import & Export Data',
    url: '/smarttables/importexport-data'
  }, {
    key: 'smarttables-json-source',
    label: 'JSON Data Source',
    url: '/smarttables/json-source'
  }, {
    key: 'smarttables-manage-records',
    label: 'Manage Records',
    url: '/smarttables/manage-records',
    badge: {
      variant: 'bg-warning text-dark',
      text: 'New'
    }
  }, {
    key: 'smarttables-fuzzy-matching',
    label: 'Fuzzy Matching',
    url: '/smarttables/fuzzy-matching'
  }, {
    key: 'smarttables-server-side',
    label: 'Server-Side Mode',
    url: '/smarttables/server-side'
  }]
}, {
  key: 'charts',
  icon: '/icons/sprite.svg#database',
  label: 'Apex Charts',
  children: [{
    key: 'charts-apex-area',
    label: 'Area Charts',
    url: '/charts/apex/area'
  }, {
    key: 'charts-apex-bar',
    label: 'Bar Charts',
    url: '/charts/apex/bar'
  }, {
    key: 'charts-apex-box-whisker',
    label: 'Box & Whisker Charts',
    url: '/charts/apex/box-whisker'
  }, {
    key: 'charts-apex-bubble',
    label: 'Bubble Charts',
    url: '/charts/apex/bubble'
  }, {
    key: 'charts-apex-candlestick',
    label: 'Candlestick Charts',
    url: '/charts/apex/candlestick'
  }, {
    key: 'charts-apex-column',
    label: 'Column Charts',
    url: '/charts/apex/column'
  }, {
    key: 'charts-apex-funnel',
    label: 'Funnel Charts',
    url: '/charts/apex/funnel'
  }, {
    key: 'charts-apex-heatmap',
    label: 'Heatmap Charts',
    url: '/charts/apex/heatmap'
  }, {
    key: 'charts-apex-line',
    label: 'Line Charts',
    url: '/charts/apex/line'
  }, {
    key: 'charts-apex-mixed-combo',
    label: 'Mixed/Combo Charts',
    url: '/charts/apex/mixed-combo'
  }, {
    key: 'charts-apex-pie-donuts',
    label: 'Pie/Donuts',
    url: '/charts/apex/pie-donuts'
  }, {
    key: 'charts-apex-polar-area',
    label: 'Polar Area Charts',
    url: '/charts/apex/polar-area'
  }, {
    key: 'charts-apex-radar',
    label: 'Radar Charts',
    url: '/charts/apex/radar'
  }, {
    key: 'charts-apex-radial-bars',
    label: 'RadialBars/Circle Charts',
    url: '/charts/apex/radial-bars'
  }, {
    key: 'charts-apex-range-area',
    label: 'Range Area Charts',
    url: '/charts/apex/range-area'
  }, {
    key: 'charts-apex-scatter',
    label: 'Scatter Charts',
    url: '/charts/apex/scatter'
  }, {
    key: 'charts-apex-slope',
    label: 'Slope Charts',
    url: '/charts/apex/slope'
  }, {
    key: 'charts-apex-sparklines',
    label: 'Sparklines',
    url: '/charts/apex/sparklines'
  }, {
    key: 'charts-apex-timeline',
    label: 'Timeline Charts',
    url: '/charts/apex/timeline'
  }, {
    key: 'charts-apex-treemap',
    label: 'Treemap Charts',
    url: '/charts/apex/treemap'
  }]
}, {
  key: 'data-bites',
  icon: '/icons/sprite.svg#grid',
  label: 'Data Bites',
  children: [{
    key: 'data-bites-peity',
    label: 'Peity Charts',
    url: '/data-bites/peity'
  }, {
    key: 'data-bites-streamline',
    label: 'Streamline',
    url: '/data-bites/streamline'
  }, {
    key: 'data-bites-easy-pie',
    label: 'Easy Pie Chart',
    url: '/data-bites/easy-pie'
  }]
}, {
  key: 'fullcalendar',
  label: 'Full Calendar',
  icon: '/icons/sprite.svg#calendar',
  url: '/fullcalendar'
}];