import { Alert, Button, Modal, ModalBody, ModalFooter, ModalHeader, ModalTitle } from 'react-bootstrap';
const DeleteConfirmationModal = ({
  show,
  onHide,
  onConfirm,
  selectedCount,
  itemName = 'row',
  confirmButtonVariant = 'danger',
  cancelButtonVariant = 'light',
  modalTitle = 'Delete record',
  confirmButtonText = 'Yes, delete',
  cancelButtonText = 'No, cancel',
  children
}) => {
  const getConfirmationMessage = () => {
    if (children) return children;
    if (selectedCount > 1) {
      return `Are you sure you want to delete these records ${selectedCount} ${itemName}s?`;
    }
    return <>
        Are you sure you want to delete record <span className="fw-600 text-danger"> [{itemName}] </span> ?
      </>;
  };
  return <Modal show={show} centered onHide={onHide} contentClassName="bg-dark bg-opacity-50 shadow-5 translucent-dark" tabIndex={-1} aria-hidden="true">
      <ModalHeader className="border-bottom-0" closeButton>
        <ModalTitle as={'h4'} className="text-white d-flex align-items-center">
          {modalTitle}
        </ModalTitle>
      </ModalHeader>
      <ModalBody>
        <Alert variant="danger" className="bg-danger border-danger text-light border-opacity-50 bg-opacity-10 mb-0">
          {getConfirmationMessage()}
          <br />
          This action cannot be undone.
        </Alert>
      </ModalBody>
      <ModalFooter className="border-top-0">
        <Button variant={cancelButtonVariant} type="button" onClick={onHide}>
          {cancelButtonText}
        </Button>
        <Button variant={confirmButtonVariant} type="button" onClick={onConfirm}>
          {confirmButtonText}
        </Button>
      </ModalFooter>
    </Modal>;
};
export default DeleteConfirmationModal;