'use client';

import 'jsvectormap';
import 'jsvectormap/dist/maps/world.js';
import 'jsvectormap/dist/maps/world-merc';
import { useEffect, useState } from 'react';
const BaseVectorMap = ({
  id,
  options,
  ...props
}) => {
  const [map, setMap] = useState();
  useEffect(() => {
    if (!map) {
      // create jsvectormap
      const map = new window['jsVectorMap']({
        selector: '#' + id,
        ...options
      });
      setMap(map);
    }
  }, [id, map, options]);
  return <div id={id} {...props} />;
};
export default BaseVectorMap;