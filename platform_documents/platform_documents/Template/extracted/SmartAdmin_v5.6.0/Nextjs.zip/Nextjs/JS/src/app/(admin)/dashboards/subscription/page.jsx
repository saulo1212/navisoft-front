'use client';

import PageBreadcrumb from '@/components/PageBreadcrumb';
import { Button, Card, CardBody, CardHeader, Col, Form, FormControl, FormGroup, FormLabel, FormSelect, InputGroup, Modal, ModalBody, ModalFooter, ModalHeader, ModalTitle, Row } from 'react-bootstrap';
import Feedback from 'react-bootstrap/Feedback';
import InputGroupText from 'react-bootstrap/InputGroupText';
import { useForm } from 'react-hook-form';
import { BsFileEarmark, BsRocketTakeoff, BsXLg } from 'react-icons/bs';
import { toast } from 'react-toastify';
import { useToggle } from 'usehooks-ts';
import { statistics } from './components/data';
import DataStream from './components/DataStream';
import DemoGraphic from './components/DemoGraphic';
import StatisticWidget from './components/StatisticWidget';
import SubscriptionFeed from './components/SubscriptionFeed';
import UserActivity from './components/UserActivity';
const Subscription = () => {
  const [show, toggle] = useToggle(false);
  const {
    register,
    handleSubmit,
    control,
    formState: {
      errors
    },
    watch
  } = useForm();
  const onError = () => {
    toast.error('Please fill required fields.', {
      hideProgressBar: true
    });
  };
  const onSubmit = data => {
    toast.success('Campaign launched successfully!', {
      hideProgressBar: true
    });
  };
  const offerType = watch('offerType');
  return <div className="content-wrapper">
      <div className="d-flex align-items-end mb-4">
        <PageBreadcrumb title={'Subscription Dashboard'} subTitle1={'Insights'} subTitle2={'Dashboards'} />

        <div className="ms-auto d-none d-sm-flex align-items-center">
          <Button variant="outline-success" className="waves-effect" type="button" onClick={toggle}>
            Build Campaign
          </Button>
        </div>
      </div>

      <div className="main-content">
        <Row className="sortable-off">
          {statistics.map((item, idx) => <Col xs={12} sm={6} xl={3} className="mb-g" key={idx}>
              <StatisticWidget item={item} />
            </Col>)}
        </Row>

        <Row>
          <Col lg={12}>
            <SubscriptionFeed />
          </Col>
          <Col lg={4}>
            <UserActivity />
          </Col>
          <Col lg={4}>
            <DataStream />
          </Col>
          <Col lg={4}>
            <DemoGraphic />
          </Col>
        </Row>
      </div>

      <Modal show={show} size={'lg'} className="fade" id="buildCampaignModal" tabIndex={-1}>
        <form onSubmit={handleSubmit(onSubmit, onError)} noValidate id="campaignForm">
          <ModalHeader closeButton className="bg-primary text-white">
            <ModalTitle as={'h5'}>Build New Subscription Campaign</ModalTitle>
          </ModalHeader>
          <ModalBody>
            <Card className="mb-4">
              <CardHeader>
                <h6 className="mb-0">Campaign Basics</h6>
              </CardHeader>
              <CardBody>
                <Row className="mb-3">
                  <Col md={6}>
                    <FormGroup controlId="campaignName">
                      <FormLabel>Campaign Name *</FormLabel>
                      <Form.Control type="text" size="lg" isInvalid={!!errors.campaignName} {...register('campaignName', {
                      required: 'Campaign name is required.'
                    })} />
                      <Feedback type="invalid">{errors.campaignName?.message}</Feedback>
                    </FormGroup>
                  </Col>
                  <Col md={6}>
                    <FormGroup controlId="campaignType">
                      <FormLabel>Campaign Type *</FormLabel>
                      <Form.Select size="lg" isInvalid={!!errors.campaignType} {...register('campaignType', {
                      required: 'Campaign type is required.'
                    })}>
                        <option value="">Select type...</option>
                        <option value="acquisition">New Customer Acquisition</option>
                        <option value="retention">Customer Retention</option>
                        <option value="winback">Win-back Campaign</option>
                        <option value="upgrade">Subscription Upgrade</option>
                      </Form.Select>
                      <Feedback type="invalid">{errors.campaignType?.message}</Feedback>
                    </FormGroup>
                  </Col>
                </Row>

                <Row className="mb-3">
                  <Col md={6}>
                    <FormGroup controlId="startDate">
                      <FormLabel>Start Date *</FormLabel>
                      <FormControl type="date" size="lg" isInvalid={!!errors.startDate} {...register('startDate', {
                      required: 'Start date is required.'
                    })} />
                      <Feedback type="invalid">{errors.startDate?.message}</Feedback>
                    </FormGroup>
                  </Col>
                  <Col md={6}>
                    <FormGroup controlId="endDate">
                      <FormLabel>End Date</FormLabel>
                      <Form.Control type="date" size="lg" {...register('endDate')} />
                    </FormGroup>
                  </Col>
                </Row>

                <FormGroup controlId="campaignDescription">
                  <FormLabel>Description</FormLabel>
                  <Form.Control as="textarea" rows={2} {...register('campaignDescription')} />
                </FormGroup>
              </CardBody>
            </Card>

            <Card className="mb-4">
              <CardHeader>
                <h6 className="mb-0">Audience & Offer</h6>
              </CardHeader>
              <CardBody>
                <FormGroup controlId="targetAudience" className="mb-4">
                  <FormLabel>Target Audience *</FormLabel>
                  <FormSelect size="lg" isInvalid={!!errors.targetAudience} {...register('targetAudience', {
                  required: 'Target audience is required.'
                })}>
                    <option value="">Select audience...</option>
                    <option value="all">All Subscribers</option>
                    <option value="active">Active Subscribers</option>
                    <option value="inactive">Inactive Subscribers</option>
                    <option value="expired">Recently Expired</option>
                    <option value="custom">Custom Segment</option>
                  </FormSelect>
                  <Feedback type="invalid">{errors.targetAudience?.message}</Feedback>
                </FormGroup>

                <FormGroup className="mb-4">
                  <FormLabel>Offer Type *</FormLabel>
                  {['discount', 'freeTrial', 'upgrade', 'bundle'].map(type => <Form.Check key={type} type="radio" id={`offer-${type}`} label={type} value={type} isInvalid={!!errors.offerType} {...register('offerType', {
                  required: 'Please select an offer type.'
                })} />)}
                  {errors.offerType && <div className="invalid-feedback d-block">{errors.offerType.message}</div>}
                </FormGroup>

                {offerType === 'discount' && <FormGroup className="mb-3">
                    <FormLabel>Discount Amount</FormLabel>
                    <Form.Range min={5} max={50} step={5} {...register('discountAmount')} />
                  </FormGroup>}
              </CardBody>
            </Card>

            <Card className="mb-4">
              <CardHeader>
                <h6 className="mb-0">Channels & Budget</h6>
              </CardHeader>
              <CardBody>
                <FormLabel>Campaign Channels *</FormLabel>
                <Row>
                  {['email', 'sms', 'push', 'inapp'].map(channel => <Col md={3} key={channel}>
                      <Form.Check type="checkbox" label={channel} id={`channel-${channel}`} value={channel} isInvalid={!!errors.campaignChannels} {...register('campaignChannels', {
                    validate: value => value.length > 0 || 'Select at least one channel.'
                  })} />
                    </Col>)}
                </Row>
                {errors.campaignChannels && <div className="invalid-feedback d-block">{errors.campaignChannels.message}</div>}

                <Row className="mt-4">
                  <Col md={6} className="mb-3">
                    <FormGroup controlId="campaignBudget">
                      <FormLabel>Budget Allocation</FormLabel>
                      <InputGroup>
                        <InputGroupText>$</InputGroupText>
                        <Form.Control type="number" size="lg" {...register('campaignBudget')} />
                      </InputGroup>
                    </FormGroup>
                  </Col>
                  <Col md={6} className="mb-3">
                    <FormGroup controlId="priority">
                      <FormLabel>Priority</FormLabel>
                      <Form.Select size="lg" {...register('priority')} defaultValue="medium">
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                      </Form.Select>
                    </FormGroup>
                  </Col>
                </Row>
              </CardBody>
            </Card>

            <Card className="mb-4">
              <Card.Header>
                <h6 className="mb-0">Performance Goals</h6>
              </Card.Header>
              <Card.Body>
                <Row>
                  <Col md={4} className="mb-3">
                    <FormGroup controlId="kpiConversions">
                      <FormLabel>Conversion Target</FormLabel>
                      <InputGroup>
                        <Form.Control type="number" {...register('kpiConversions')} />
                        <InputGroupText>subscribers</InputGroupText>
                      </InputGroup>
                    </FormGroup>
                  </Col>
                  <Col md={4} className="mb-3">
                    <FormGroup controlId="kpiRevenue">
                      <FormLabel>Revenue Target</FormLabel>
                      <InputGroup>
                        <InputGroupText>$</InputGroupText>
                        <Form.Control type="number" {...register('kpiRevenue')} />
                      </InputGroup>
                    </FormGroup>
                  </Col>
                  <Col md={4} className="mb-3">
                    <FormGroup controlId="kpiROI">
                      <FormLabel>ROI Target</FormLabel>
                      <InputGroup>
                        <Form.Control type="number" {...register('kpiROI')} />
                        <InputGroupText>%</InputGroupText>
                      </InputGroup>
                    </FormGroup>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </ModalBody>
          <ModalFooter>
            <Button variant="outline-secondary" className="waves-effect" type="button" onClick={toggle}>
              <BsXLg />
              Cancel
            </Button>
            <Button variant="outline-primary" className="waves-effect" type="button" id="saveDraftBtn">
              <BsFileEarmark className="me-1" />
              Save Draft
            </Button>
            <Button variant="success" className="waves-effect" type="submit">
              <BsRocketTakeoff className="me-1" />
              Launch Campaign
            </Button>
          </ModalFooter>
        </form>
      </Modal>
    </div>;
};
export default Subscription;