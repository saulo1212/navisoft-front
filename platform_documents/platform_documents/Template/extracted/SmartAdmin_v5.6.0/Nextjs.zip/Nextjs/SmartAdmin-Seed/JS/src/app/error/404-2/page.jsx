import Link from "next/link";
import BackgroundAnimation from "@/components/BackgroundAnimation";
import { Col, Container, Row } from "react-bootstrap";
const page = () => {
  return <section className="hero-section position-relative overflow-hidden">
            <Container style={{
      position: "relative",
      zIndex: 1
    }}>
                <Row className="justify-content-center">
                    <Col xs={11} md={8} lg={6} xl={4}>
                        <div className="login-card p-4 p-md-6 bg-dark bg-opacity-50 translucent-dark rounded-4 text-center">
                            <div className="mb-5 mx-auto" style={{
              maxWidth: 100
            }}>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <g fill="none" fillRule="evenodd" clipRule="evenodd">
                                        <path fill="#fff" d="M12.276 15.59c-.277-.662-2.117-.054-2.874 1.706a5.39 5.39 0 0 0 .964 5.877a2.99 2.99 0 0 0 4.592-1.473a7.12 7.12 0 0 0-.94-5.43c-.414-.458-1.353-.988-1.742-.68m-.136.496a2.17 2.17 0 0 0-1.713 1.603a4.5 4.5 0 0 0 .727 4.404a1.69 1.69 0 0 0 2.567-.83c.33-.883.375-4.492-1.263-4.906a.43.43 0 0 1-.318-.271" />
                                        <path fill="#ff0c0c" d="M13.019.337c-.2-.458-1.431-.39-2.078-.146a9.2 9.2 0 0 0-3.608 4.108c-3.192 5.907-3.78 9.218 2.746 9.734c2.484.177 4.98-.078 7.377-.754a2.44 2.44 0 0 0 1.705-2.763C18.929 8.668 14.624-.528 13.019.336m-.2.536a.4.4 0 0 1-.276.028C9.386.25 6.273 9.22 6.32 10.718c.082 2.829 8.758 2.105 10.629 1.342c.69-.276 1.014-.596.93-1.41a25 25 0 0 0-1.657-4.49C13.502.143 13.062 1.527 12.82.875z" />
                                        <path fill="#ff0c0c" d="M12.46 9.179c-.25-.702-2.486-.172-1.914 1.533a1.381 1.381 0 0 0 2.567.141c.406-.975-.238-1.666-.652-1.674zm-.121-1.13c1.177-5.432-2-8.29-.83-.03a.415.415 0 1 0 .83.03" />
                                        <path fill="#fff" d="M19.917 21.432c.243 2.04.23 2.62.754 2.565c.525-.056.33-.415.276-2.708c.83-.133 1.758-.108 1.692-.694c-.067-.585-.813-.356-1.71-.298c-.042-2.263-.034-2.21-.147-4.24c-.166-2.507-5.338 3.336-4.68 4.745c.45.926 2.782.744 3.815.63m-.122-1.077c-.11-1.105-.149-1.735-.237-2.926a10 10 0 0 0-1.79 2.27c-.46.896-.49.515.276.595q.873.09 1.751.053zM5.35 21.07c.222 1.882.206 2.763.772 2.71s.326-.477.277-2.781c.878-.07 1.76-.022 1.693-.62c-.058-.513-.552-.353-1.713-.367c-.038-2.183-.036-2.166-.143-4.17a.666.666 0 0 0-1.028-.513A19.2 19.2 0 0 0 1.38 20.34a.67.67 0 0 0 .627.845s1.724-.027 3.343-.116m-.117-1.077c-.097-1.01-.12-1.382-.213-2.647a30 30 0 0 0-1.934 2.583c.602.022 1.38.047 2.147.064" />
                                    </g>
                                </svg>
                            </div>
                            <h4 className="text-white mb-2">Page Not Found</h4>
                            <p className="text-white opacity-50 mb-4">
                                Sorry, the page you are looking for doesn’t exist or has been moved.
                            </p>

                            <div className="mb-4">
                                <Link href="/" className="btn btn-primary me-2">Back to Home</Link>
                                <Link href="" className="btn btn-success">Contact Support</Link>
                            </div>

                            <div className="opacity-50 text-white small">
                                If you believe this is a mistake, please let us know.
                            </div>
                        </div>

                    </Col>
                </Row>
            </Container>

            <BackgroundAnimation />

        </section>;
};
export default page;