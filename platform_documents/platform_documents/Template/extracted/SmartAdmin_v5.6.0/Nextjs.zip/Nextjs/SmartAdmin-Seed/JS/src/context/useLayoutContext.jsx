'use client';

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';
import { toggleAttribute } from '@/helpers/layout';
import { basePath } from "@/helpers";
const INIT_STATE = {
  theme: 'light',
  headerFixed: false,
  navFull: false,
  navFixed: false,
  navCollapsed: false,
  navMinified: false,
  darkNavigation: true,
  colorblindMode: false,
  highContrastMode: false,
  selectedTheme: 'default'
};
const LayoutContext = createContext(undefined);
export const useLayoutContext = () => {
  const context = useContext(LayoutContext);
  if (!context) throw new Error('useLayoutContext can only be used within LayoutProvider');
  return context;
};
export const LayoutProvider = ({
  children
}) => {
  const [settings, setSettings] = useLocalStorage('__SMART_ADMIN_NEXT_CONFIG__', INIT_STATE);
  const [offcanvasStates, setOffcanvasStates] = useState({
    showCustomizer: false
  });
  const getClassNameForSetting = setting => {
    const map = {
      headerFixed: 'set-header-fixed',
      navFull: 'set-nav-full',
      navFixed: 'set-nav-fixed',
      navCollapsed: 'set-nav-collapsed',
      navMinified: 'set-nav-minified',
      darkNavigation: 'set-nav-dark',
      colorblindMode: 'set-colorblind-mode',
      highContrastMode: 'set-high-contrast-mode'
    };
    return map[setting] || '';
  };
  const toggleSetting = useCallback((key, value) => {
    const className = getClassNameForSetting(key);
    document.documentElement.classList.toggle(className, value);
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  }, [setSettings]);
  const changeTheme = useCallback((theme, persist = true) => {
    toggleAttribute('data-bs-theme', theme);
    if (persist) setSettings(prev => ({
      ...prev,
      theme
    }));
  }, [setSettings]);
  const changeThemeStyle = useCallback(themeId => {
    const themeStyleEl = document.getElementById('app-theme');
    if (themeId === 'default') {
      if (themeStyleEl) themeStyleEl.href = '';
      setSettings(prev => ({
        ...prev,
        selectedTheme: themeId
      }));
      return;
    } else {
      if (themeStyleEl) themeStyleEl.href = themeId ? `${basePath}/css/${themeId}.css` : '';
      setSettings(prev => ({
        ...prev,
        selectedTheme: themeId
      }));
    }
  }, [setSettings]);
  const reset = useCallback(() => {
    const htmlRoot = document.documentElement;
    const themeStyleEl = document.getElementById('theme-style');
    const classesToRemove = ['set-header-fixed', 'set-nav-full', 'set-nav-fixed', 'set-nav-collapsed', 'set-nav-minified', 'set-nav-dark', 'set-colorblind-mode', 'set-high-contrast-mode'];
    classesToRemove.forEach(cls => htmlRoot.classList.remove(cls));
    if (themeStyleEl) themeStyleEl.href = '';
    setSettings(INIT_STATE);
    localStorage.removeItem('panelStates');
  }, [setSettings]);
  const showBackdrop = () => {
    const backdrop = document.createElement('div');
    backdrop.id = 'custom-backdrop';
    backdrop.className = 'offcanvas-backdrop sidenav-backdrop fade show';
    document.body.appendChild(backdrop);
    document.body.style.overflow = 'hidden';
    if (window.innerWidth > 767) document.body.style.paddingRight = '15px';
    backdrop.addEventListener('click', () => {
      document.documentElement.classList.remove('app-mobile-menu-open');
      hideBackdrop();
    });
  };
  const hideBackdrop = () => {
    const backdrop = document.getElementById('custom-backdrop');
    if (backdrop) {
      document.body.removeChild(backdrop);
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
    }
  };
  const toggleCustomizer = () => {
    setOffcanvasStates(prev => ({
      ...prev,
      showCustomizer: !prev.showCustomizer
    }));
  };
  const customizer = useMemo(() => ({
    isOpen: offcanvasStates.showCustomizer,
    toggle: toggleCustomizer
  }), [offcanvasStates]);
  useEffect(() => {
    toggleAttribute('data-bs-theme', settings.theme);
    const themeStyleEl = document.getElementById('app-theme');
    if (themeStyleEl && settings.selectedTheme == 'default') {
      themeStyleEl.href = settings.selectedTheme && '';
    }
    if (themeStyleEl && settings.selectedTheme !== 'default') {
      themeStyleEl.href = settings.selectedTheme ? `${basePath}/css/${settings.selectedTheme}.css` : '';
    }
    Object.entries(settings).forEach(([key, val]) => {
      if (typeof val === 'boolean') {
        const className = getClassNameForSetting(key);
        if (className) document.documentElement.classList.toggle(className, val);
      }
    });
  }, [settings]);
  const contextValue = useMemo(() => ({
    ...settings,
    settings,
    changeTheme,
    changeThemeStyle,
    toggleSetting,
    reset,
    showBackdrop,
    hideBackdrop,
    customizer
  }), [settings, changeTheme, changeThemeStyle, toggleSetting, reset, customizer]);
  return <LayoutContext.Provider value={contextValue}>
            {children}
        </LayoutContext.Provider>;
};